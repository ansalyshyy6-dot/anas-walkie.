package com.sada.walkie

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/**
 * قناة إشارات المكالمات: رسالة JSON واحدة لكل اتصال TCP على المنفذ 40124.
 * تُستخدم فقط لتبادل (دعوة/رد/عرض/إجابة/ICE)؛ الصوت والصورة نفسهما يمران عبر WebRTC.
 */
object CallSignal {
    const val PORT = 40124
    private const val MAX_BYTES = 128 * 1024
    private const val CH = "sada_call"
    private const val NOTIF_ID = 8
    private const val STALE_MS = 40_000L

    @Volatile private var sink: ((String, String) -> Unit)? = null
    @Volatile var uiVisible = false

    private val lock = Any()
    private var server: ServerSocket? = null
    private val pending = ArrayList<Triple<Long, String, String>>()
    private val ipRe = Regex("""\d{1,3}(\.\d{1,3}){3}""")
    private val sender = Executors.newSingleThreadExecutor { r -> Thread(r, "sada-sig-tx").also { it.isDaemon = true } }
    private val readers = Executors.newCachedThreadPool { r -> Thread(r, "sada-sig-rx").also { it.isDaemon = true } }

    fun start(ctx: Context) {
        val app = ctx.applicationContext
        synchronized(lock) {
            if (server != null) return
            val s = try {
                ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) }
            } catch (_: Exception) { return }
            server = s
            Thread({ acceptLoop(app, s) }, "sada-sig-accept").also { it.isDaemon = true }.start()
        }
    }

    fun stop() {
        synchronized(lock) {
            try { server?.close() } catch (_: Exception) {}
            server = null
            pending.clear()
        }
    }

    /** تربط الواجهة (WebView) بالقناة، وتسلّمها الدعوات التي وصلت أثناء غيابها. */
    fun attach(f: (String, String) -> Unit) {
        sink = f
        val now = System.currentTimeMillis()
        val list = synchronized(lock) { val l = ArrayList(pending); pending.clear(); l }
        for ((t, m, ip) in list) if (now - t < STALE_MS) f(m, ip)
    }

    fun detach() { sink = null }

    fun send(ip: String, json: String, onFail: () -> Unit) {
        if (!ipRe.matches(ip)) { onFail(); return }
        sender.execute {
            var ok = false
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(ip, PORT), 2500)
                    s.soTimeout = 3000
                    val o = s.getOutputStream()
                    o.write(json.toByteArray(Charsets.UTF_8))
                    o.flush()
                    s.shutdownOutput()
                    ok = true
                }
            } catch (_: Exception) {}
            if (!ok) onFail()
        }
    }

    private fun acceptLoop(app: Context, s: ServerSocket) {
        while (!s.isClosed) {
            try {
                val c = s.accept()
                readers.execute { readOne(app, c) }
            } catch (_: Exception) {
                if (s.isClosed) break
            }
        }
    }

    private fun readOne(app: Context, c: Socket) {
        try {
            c.use {
                it.soTimeout = 4000
                val ip = it.inetAddress?.hostAddress ?: return
                val t0 = System.currentTimeMillis()
                val out = ByteArrayOutputStream()
                val tmp = ByteArray(4096)
                val ins = it.getInputStream()
                while (true) {
                    val n = ins.read(tmp)
                    if (n < 0) break
                    out.write(tmp, 0, n)
                    if (out.size() > MAX_BYTES || System.currentTimeMillis() - t0 > 8000) return
                }
                if (out.size() > 0) deliver(app, String(out.toByteArray(), Charsets.UTF_8), ip)
            }
        } catch (_: Exception) {}
    }

    private fun deliver(app: Context, msg: String, ip: String) {
        val kind = try { JSONObject(msg).optString("t") } catch (_: Exception) { return }
        if (kind == "cancel" || kind == "end") cancelNotif(app)
        val f = sink
        if (f != null) {
            f(msg, ip)
        } else {
            synchronized(lock) {
                pending.add(Triple(System.currentTimeMillis(), msg, ip))
                while (pending.size > 40) pending.removeAt(0)
            }
        }
        if (kind == "invite" && (f == null || !uiVisible)) notifyInvite(app, msg)
    }

    private fun notifyInvite(app: Context, msg: String) {
        try {
            val j = JSONObject(msg)
            val who = j.optString("name").take(24).ifBlank { "جهاز" }
            val video = j.optString("kind") == "video"
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CH, "المكالمات الواردة", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pi = PendingIntent.getActivity(
                app, 2,
                Intent(app, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(app, CH)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle(if (video) "مكالمة فيديو واردة" else "مكالمة صوتية واردة")
                .setContentText(who)
                .setContentIntent(pi)
                .setCategory(Notification.CATEGORY_CALL)
                .setAutoCancel(true)
                .setTimeoutAfter(STALE_MS)
                .build()
            nm.notify(NOTIF_ID, n)
        } catch (_: Exception) {}
    }

    fun cancelNotif(ctx: Context) {
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID)
        } catch (_: Exception) {}
    }
}
